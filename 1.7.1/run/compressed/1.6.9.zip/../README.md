Welcome to VillageWars!

Read the wiki at https://villagewars.pythonanywhere.com/wiki/VillageWars Wiki or login at https://villagewars.pythonanywhere.com!